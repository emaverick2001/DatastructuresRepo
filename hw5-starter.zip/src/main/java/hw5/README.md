# Discussion

## Flawed Deque



## Hacking Linear Search



## Profiling

