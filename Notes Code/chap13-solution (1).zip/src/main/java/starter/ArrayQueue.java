package starter;

import exceptions.EmptyException;

/**
 * Array Implementation of the Queue ADT.
 *
 * @param <T> base type.
 */
public class ArrayQueue<T> implements Queue<T> {

  @Override
  public void enqueue(T value) {
    // TODO: Implement me!
  }

  @Override
  public void dequeue() throws EmptyException {
    // TODO: Implement me!
  }

  @Override
  public T front() throws EmptyException {
    return null; // TODO: Implement me!
  }

  @Override
  public boolean empty() {
    return false; // TODO: Implement me!
  }
}
