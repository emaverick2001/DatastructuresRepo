package starter;

import exceptions.EmptyException;

/**
 * Stack ADT implemented using an array.
 *
 * @param <T> base type.
 */
public class ArrayStack<T> implements Stack<T> {
  private T[] data;
  private int capacity;
  private int numElements;

  /**
   * Construct an ArrayStack.
   */
  public ArrayStack() {
    capacity = 10;
    data = (T[]) new Object[capacity];
    numElements = 0;
  }

  @Override
  public boolean empty() {
    return false; // TODO: Implement me!
  }

  @Override
  public T top() throws EmptyException {
    return null; // TODO: Implement me!
  }

  @Override
  public void pop() throws EmptyException {
    // TODO: Implement me!
  }

  @Override
  public void push(T value) {
    // TODO: Implement me!
  }
}
