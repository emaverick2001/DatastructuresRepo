package starter;

import java.util.Iterator;

public class BinarySearchTreeMap<K extends Comparable<K>, V>
    implements OrderedMap<K, V> {
  @Override
  public void insert(K k, V v) throws IllegalArgumentException {
    // TODO Implement me.
  }

  @Override
  public V remove(K k) throws IllegalArgumentException {
    // TODO Implement me.
    return null;
  }

  @Override
  public void put(K k, V v) throws IllegalArgumentException {
    // TODO Implement me.
  }

  @Override
  public V get(K k) throws IllegalArgumentException {
    // TODO Implement me.
    return null;
  }

  @Override
  public boolean has(K k) {
    // TODO Implement me.
    return false;
  }

  @Override
  public int size() {
    // TODO Implement me.
    return 0;
  }

  @Override
  public Iterator<K> iterator() {
    // TODO Implement me.
    return null;
  }
}
