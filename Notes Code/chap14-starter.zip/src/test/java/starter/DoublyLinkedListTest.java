package starter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DoublyLinkedListTest {
  private DoublyLinkedList<Integer> linkedList;

  @BeforeEach
  void setUp() {
    linkedList = new DoublyLinkedList<>();
  }

  @Test
  void test() {
    // TODO write tests!
  }
}