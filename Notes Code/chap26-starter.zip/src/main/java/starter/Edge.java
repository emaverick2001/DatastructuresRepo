package starter;

/**
 * Edge position for graph.
 *
 * @param <E> Element type.
 */
public interface Edge<E> extends Position<E> {
}
