package starter;

/**
 * Vertex position for graph.
 *
 * @param <V> Element type.
 */
public interface Vertex<V> extends Position<V> {
}
