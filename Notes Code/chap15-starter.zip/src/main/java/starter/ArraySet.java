package starter;

import java.util.Iterator;

public class ArraySet<T> implements Set<T> {
  @Override
  public void insert(T t) {
    // TODO Implement Me!
  }

  @Override
  public void remove(T t) {
    // TODO Implement Me!
  }

  @Override
  public boolean has(T t) {
    // TODO Implement Me!
    return false;
  }

  @Override
  public int size() {
    // TODO Implement Me!
    return 0;
  }

  @Override
  public Iterator<T> iterator() {
    // TODO Implement Me!
    return null;
  }
}
