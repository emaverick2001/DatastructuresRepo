The implementation of Floyd's method is not provided because it
 requires implementation of `sink` which is what you need to do a homework.