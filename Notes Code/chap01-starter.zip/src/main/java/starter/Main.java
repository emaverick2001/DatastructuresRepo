package starter;

public class Main {
  /**
   * Execution starts here.
   * @param args command-line arguments.
   */
  public static void main(String[] args) {
    System.out.println("Hello Data Structures!");
  }
}
