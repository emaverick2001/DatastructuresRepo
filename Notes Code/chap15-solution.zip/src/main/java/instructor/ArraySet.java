package instructor;

import java.util.Iterator;

public class ArraySet<T> implements Set<T> {
  @Override
  public void insert(T t) {

  }

  @Override
  public void remove(T t) {

  }

  @Override
  public boolean has(T t) {
    return false;
  }

  @Override
  public int size() {
    return 0;
  }

  @Override
  public Set<T> union(Set<T> other) {
    return null;
  }

  @Override
  public Set<T> intersect(Set<T> other) {
    return null;
  }

  @Override
  public Set<T> subtract(Set<T> other) {
    return null;
  }

  @Override
  public Iterator<T> iterator() {
    return null;
  }
}
