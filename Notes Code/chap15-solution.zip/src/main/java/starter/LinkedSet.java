package starter;

import java.util.Iterator;

public class LinkedSet<T> implements Set<T> {
  @Override
  public void insert(T t) {
    // TODO: Implement me!
  }

  @Override
  public void remove(T t) {
    // TODO: Implement me!
  }

  @Override
  public boolean has(T t) {
    // TODO: Implement me!
    return false;
  }

  @Override
  public int size() {
    // TODO: Implement me!
    return 0;
  }

  @Override
  public Iterator<T> iterator() {
    // TODO: Implement me!
    return null;
  }
}
