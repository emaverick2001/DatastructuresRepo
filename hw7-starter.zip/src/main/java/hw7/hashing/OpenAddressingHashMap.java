package hw7.hashing;

import hw7.Map;
import java.util.Iterator;

public class OpenAddressingHashMap<K, V> implements Map<K, V> {
  @Override
  public void insert(K k, V v) throws IllegalArgumentException {
    // TODO Implement Me!
  }

  @Override
  public V remove(K k) throws IllegalArgumentException {
    // TODO Implement Me!
    return null;
  }

  @Override
  public void put(K k, V v) throws IllegalArgumentException {
    // TODO Implement Me!
  }

  @Override
  public V get(K k) throws IllegalArgumentException {
    // TODO Implement Me!
    return null;
  }

  @Override
  public boolean has(K k) {
    // TODO Implement Me!
    return false;
  }

  @Override
  public int size() {
    // TODO Implement Me!
    return 0;
  }

  @Override
  public Iterator<K> iterator() {
    // TODO Implement Me!
    return null;
  }
}
