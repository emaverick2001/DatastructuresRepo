# Discussion
explain which of your implementations (between OpenAddressingHashMap and ChainingHashMap) is a better choice to be used for the search engine.
Which approaches did you try to implement each hash table (e.g., probing strategies, rehashing strategies, etc.), and why did you choose them?
What specific tweaks to your implementation improved or made things worse? Make note of failed or abandoned attempts, if any.
In summary, describe all the different ways you developed, evaluated, and improved your hash tables.
Include all the benchmarking data, results, and analysis that contributed to your final decision on which implementation to use for the search engine.
Moreover, why did you choose your final Map implementation as the best one? Provide an analysis of your benchmark data and conclusions.
What results were surprising, and which were expected?

After running JmhRuntimeTest, from the results it appears that openAddressingHashMap takes the least amount of time and space and this intuitively makes sense since with my implementation
of chaining

ChainingHashMap

Space Complexity

JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               apache.txt  avgt    2   114678292.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc                  jhu.txt  avgt    2    18481800.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               joanne.txt  avgt    2    18523916.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               newegg.txt  avgt    2    65240160.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc            random164.txt  avgt    2   376494392.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc                 urls.txt  avgt    2    17805932.000           bytes

Time Complexity
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             apache.txt  avgt    2          76.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                                jhu.txt  avgt    2          27.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             joanne.txt  avgt    2          32.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             newegg.txt  avgt    2          76.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                          random164.txt  avgt    2         126.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                               urls.txt  avgt    2          18.000              ms

OpenAdressingHashMap

Space Complexity

JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               jhu.txt  avgt    2   18393112.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc            joanne.txt  avgt    2   17733012.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc              urls.txt  avgt    2   17784524.000           bytes


Time Complexity

JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             jhu.txt  avgt    2         20.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                          joanne.txt  avgt    2         17.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                            urls.txt  avgt    2         16.500              ms

. In my implementation of the chaining hashtable, I thought it would
make most sense to just used linked lists as its easier to just add nodes to the end of the list instead of using an arrayList when
collisions occur. For my implementation of openAddressing hashTables, when a collision occurs, I utilized a quadratic probing strategy for
the first 5 searches then defaulted to linear probing if those 5 searches were unsuccessful. This strategy seemed to me a logical solution for
reducing clustering and when that didnt work resort to linearly searching as that would then find an empty Entry. Using quadratic probing also 
ensures the probing sequences are spread out, making it less likely for keys to collide and form clusters which makes results in a more even distribution of keys across the hashtable.
For both chaining and open addressing hashtable, when the load factor reached its threshold (0.75), I utilized a grow function that increased the table capacity and utilized
insert to reinsert previous valid keys into the new hashtable. While inserting I also made sure to keep the size consistent by decreasing the size each time I rehashed entries
into the new hashtable since these entries were present in the previous table. In rehashing, I made sure to only preserve entries that were valid (not tombstones) and by doing so
removed all the Tombstones. At first, I made my primes list an o(n) operation, scanning through each prime hashtable size when I wanted to grow instead of just keeping a
variable to keep track of the index of the prime table which would make setting the size o(1). I also improved efficiency by switching to doubling the capacity of the hashtable and
adding 1 once the table of primes was exhausted of elements. 