# Discussion
explain which of your implementations (between OpenAddressingHashMap and ChainingHashMap) is a better choice to be used for the search engine.
Which approaches did you try to implement each hash table (e.g., probing strategies, rehashing strategies, etc.), and why did you choose them?
What specific tweaks to your implementation improved or made things worse? Make note of failed or abandoned attempts, if any.
In summary, describe all the different ways you developed, evaluated, and improved your hash tables.
Include all the benchmarking data, results, and analysis that contributed to your final decision on which implementation to use for the search engine.
Moreover, why did you choose your final Map implementation as the best one? Provide an analysis of your benchmark data and conclusions.
What results were surprising, and which were expected?

ChainingHashMap:

Load factor of 0.75

Space Complexity

JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               apache.txt  avgt    2   114678292.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc                  jhu.txt  avgt    2    18481800.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               joanne.txt  avgt    2    18523916.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               newegg.txt  avgt    2    65240160.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc            random164.txt  avgt    2   376494392.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc                 urls.txt  avgt    2    17805932.000           bytes

Time Complexity
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             apache.txt  avgt    2          76.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                                jhu.txt  avgt    2          27.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             joanne.txt  avgt    2          32.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             newegg.txt  avgt    2          76.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                          random164.txt  avgt    2         126.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                               urls.txt  avgt    2          18.000              ms

OpenAdressingHashMap:

Load factor of 0.75

Space Complexity

JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               apache.txt  avgt    2   77578776.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc                  jhu.txt  avgt    2   18065240.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               joanne.txt  avgt    2   17484156.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               newegg.txt  avgt    2   63493592.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc            random164.txt  avgt    2  255422428.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc                 urls.txt  avgt    2   17831728.000           bytes

Time Complexity

JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             apache.txt  avgt    2         19.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                                jhu.txt  avgt    2         26.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             joanne.txt  avgt    2         14.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             newegg.txt  avgt    2          9.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                          random164.txt  avgt    2         84.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                               urls.txt  avgt    2         17.000              ms
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
ChainingHashMap:

Load factor of 0.5

Space Complexity

JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               apache.txt  avgt    2   136420396.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             apache.txt  avgt    2         115.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc                  jhu.txt  avgt    2    18488376.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                                jhu.txt  avgt    2          36.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               joanne.txt  avgt    2    18287372.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             joanne.txt  avgt    2          37.000              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc               newegg.txt  avgt    2    69494336.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                             newegg.txt  avgt    2          78.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc            random164.txt  avgt    2  2907688704.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                          random164.txt  avgt    2        1115.500              ms
JmhRuntimeTest.buildSearchEngine:+c2k.gc.maximumUsedAfterGc                 urls.txt  avgt    2    17792516.000           bytes
JmhRuntimeTest.buildSearchEngine:+c2k.gc.time                               urls.txt  avgt    2          18.500              ms

OpenAdressingHashMap:

Load factor of 0.5

Space Complexity

Analysis:

After running JmhRuntimeTest, from the results it appears that openAddressingHashMap takes the least amount of time and space and this intuitively makes sense since with my implementation
of chaining

. 

In my implementation of the chaining hashtable, I used linked lists instead of using an arrayList, however using the latter would be more space and time efficient, as
you wouldnt have to traverse a bucket from start to get the last entry in the bucket. Using an arrayList also provides Random access. Insertion and deletion would be efficient
since we don't worry about keeping entries in the bucket sorted so when a new entry is added to a bucket it can be directly added to the front or the end in o(1) time.
For my implementation of openAddressing hashTables, when a collision occurs, I utilized a quadratic probing strategy for
the first 5 searches then defaulted to linear probing if those 5 searches were unsuccessful. This strategy seemed to me a logical solution for
reducing clustering and when that didn't work resort to linearly searching as that would then find an empty Entry. Using quadratic probing also 
ensures the probing sequences are spread out, making it less likely for keys to collide and form clusters which results in a more even distribution of keys across the hashtable.
For both chaining and open addressing hashtable, when the load factor reached its threshold (0.75), I utilized a grow function that increased the table capacity and utilized
insert to reinsert previous valid keys into the new hashtable. While inserting I also made sure to keep the size consistent by decreasing the size each time I rehashed entries
into the new hashtable since these entries were present in the previous table. In rehashing, I made sure to only preserve entries that were valid (not tombstones) and by doing so
removed all the Tombstones. At first, I made my primes list an o(n) operation, scanning through each prime hashtable size when I wanted to grow instead of just keeping a
variable to keep track of the index of the prime table which would make setting the size o(1). I also improved efficiency by switching to doubling the capacity of the hashtable and
adding 1 once the table of primes was exhausted of elements. To improve the efficiency of my rehashing in my grow function, instead of creating a new temporary array to hold all the entries from 
the original array, I was able to switch to doing a direct copy from the old hashtable into the new one, reducing the space and time complexity overall.