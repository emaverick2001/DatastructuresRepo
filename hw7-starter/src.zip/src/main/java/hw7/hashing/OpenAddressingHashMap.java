package hw7.hashing;

import hw7.Map;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class OpenAddressingHashMap<K, V> implements Map<K, V> {
  private static final int DEFAULT_CAPACITY = 5;
  private static final float DEFAULT_LOAD_FACTOR = 0.75f;

  private int capacity;
  private float loadFactor;
  private int size;
  private int tsSize;
  private Entry<K, V>[] data;

  public OpenAddressingHashMap() {
    capacity = DEFAULT_CAPACITY;
    loadFactor = DEFAULT_LOAD_FACTOR;
    data = new Entry[capacity];
    size = 0;
    tsSize = 0;
  }

  // Entry to store a key, and a value pair.
  private static class Entry<K,V> {
    K key;
    V value;

    Entry(K k, V v) {
      this.key = k;
      this.value = v;
    }
  }

  public int getCapacity() {
    return capacity;
  }

  private void grow() {
    // temp to hold old hashmap
    Entry<K,V>[] temp = data;
    int prevLength = temp.length;

    int prIndex = 0;
    int[] primes = {3, 11, 23, 47, 89, 97, 193, 389};
    while (data.length >= primes[prIndex]) {
      prIndex++;
    }
    capacity = primes[prIndex];

    // create new hashmap with next largest prime # capacity
    Entry<K,V>[] newHash = new Entry[capacity];
    Entry<K,V>[] pairs = new Entry[size];
    int pIndex = 0;
    // get all entries from old hashmap

    for (Entry<K, V> kvEntry : temp) {
      if (kvEntry != null) {
        pairs[pIndex++] = kvEntry;
      }
    }
    // have filled entry array
    data = newHash;
    pIndex = 0;
    // rehash old hasmap keys into new hashmap since capacity changes
    for (int i = 0; i < size; i++) {
      insert(pairs[pIndex].key,pairs[pIndex].value);
      size--;
      pIndex++;
    }
  }

  private boolean hasKey(K k) {
    int currentIndex = 0;
    // traverse array of entries and check if a key has
    while (currentIndex < data.length) {
      if (data[currentIndex] != null && data[currentIndex].key.equals(k)) {
        return true;
      }
      currentIndex++;
    }
    return false;
  }

  @Override
  public void insert(K k, V v) throws IllegalArgumentException {
    if (k == null || has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    Entry<K,V> current = data[index];

    // element at index is empty or has TS
    if (current == null || current.key.equals("TS")) {
      data[index] = new Entry<>(k,v);
      size++;
      loadFactor = ((float) size + tsSize) / capacity;
      if (loadFactor >= DEFAULT_LOAD_FACTOR) {
        grow();
      }
      return;
    }
    // move current 1 element forward
    index = ++index % capacity;
    current = data[index];

    // find next available spot
    int quadProbeCount = 1;
    while (current != null) {
      // check for TS
      if (current.key.equals("TS")) {
        tsSize--;
        size++;
        current.key = k;
        current.value = v;
        return;
      }

      // move to the next entry (first 5 searches are quad, then linear)
      if (quadProbeCount > 5) {
        current = data[++index % capacity];
      } else {
        index = (index + quadProbeCount * quadProbeCount) % capacity;
        current = data[index];
        quadProbeCount++;
      }
    }

    // found empty entry
    data[index] = new Entry<>(k,v);
    size++;
    loadFactor = ((float) size + tsSize) / capacity;
    if (loadFactor >= DEFAULT_LOAD_FACTOR) {
      grow();
    }
  }

  @Override
  public V remove(K k) throws IllegalArgumentException {
    if (k == null || !has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    // key corresponds to k else shifted due to probing
    if (data[index].key.equals(k)) {
      V temp;
      temp = data[index].value;
      tsSize++;
      size--;
      data[index].key = (K)"TS";
      return temp;
    }
    // move to next entry
    index = ++index % capacity;
    // traverse hashmap to find entry (shifted due to probing)
    while (data[index] != null && !data[index].key.equals(k)) {
      index = ++index % capacity;
    }
    V temp;
    temp = data[index].value;
    tsSize++;
    size--;
    data[index].key = (K)"TS";
    return temp;
  }

  // TODO can put convert TS to an entry?
  // TODO can we have null values?
  @Override
  public void put(K k, V v) throws IllegalArgumentException {
    if (k == null || !has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    // key corresponds to k else shifted due to probing
    if (data[index].key.equals(k)) {
      data[index].value = v;
      return;
    }
    // move to next entry
    index = ++index % capacity;
    // traverse hashmap to find entry (shifted due to probing)
    while (data[index] != null && !data[index].key.equals(k)) {
      index = ++index % capacity;
    }
    // found entry corresponding with key corresponding to k
    data[index].value = v;

  }

  @Override
  public V get(K k) throws IllegalArgumentException {
    if (k == null || !has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    // key corresponds to k else shifted due to probing
    if (data[index].key.equals(k)) {
      return data[index].value;
    }
    // move to next entry
    index = ++index % capacity;
    // traverse hashmap to find entry (shifted due to probing)
    while (data[index] != null && !data[index].key.equals(k)) {
      index = ++index % capacity;
    }
    return data[index].value;
  }

  @Override
  public boolean has(K k) {
    if (k != null) {
      int index = k.hashCode() % capacity;

      // Check if the entry at the computed index matches the key
      if (data[index] != null && data[index].key.equals(k)) {
        return true;
      }

      // Check for probing (linear probing in this case)
      for (int i = 1; i < capacity; i++) {
        int newIndex = (index + i) % capacity;

        // Check if the entry at the probed index matches the key
        if (data[newIndex] != null && data[newIndex].key.equals(k)) {
          return true;
        }
      }
    }
    // not in hashmap
    return false;
  }

  @Override
  public int size() {
    return size;
  }

  @Override
  public Iterator<K> iterator() {
    return new HashIterator();
  }

  private class HashIterator implements Iterator<K> {

    private int currentIndex; // Index for array traversal

    HashIterator() {
      currentIndex = 0;
      findNext(); // Move to the first valid entry
    }

    @Override
    public boolean hasNext() {
      return currentIndex < data.length;
    }

    @Override
    public K next() {
      if (!hasNext()) {
        throw new NoSuchElementException();
      }

      K key = data[currentIndex].key;
      currentIndex++;

      // If currentIndex is within bounds, find the next non-null entry
      findNext();

      return key;
    }

    // Helper method to find the next valid entry in the array
    private void findNext() {
      while (currentIndex < data.length && data[currentIndex] == null) {
        currentIndex++;
      }
    }
  }

}
