package hw7.hashing;

//import com.sun.tools.javac.jvm.Code;
import hw7.Map;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class ChainingHashMap<K, V> implements Map<K, V> {

  private static final int DEFAULT_CAPACITY = 5;
  private static final float DEFAULT_LOAD_FACTOR = 0.75f;

  private int capacity;
  private float loadFactor;
  private int size;
  private Entry<K,V>[] data;

  /**
   * Instantiate JdkHashMap.
   */
  public ChainingHashMap() {
    capacity = DEFAULT_CAPACITY;
    loadFactor = DEFAULT_LOAD_FACTOR;
    data = new Entry[capacity];
    size = 0;
  }

  // Entry to store a key, and a value pair.
  private static class Entry<K,V> {
    K key;
    V value;

    Entry<K,V> next;

    Entry(K k, V v) {
      this.key = k;
      this.value = v;
      next = null;
    }
  }

  public int getCapacity() {
    return capacity;
  }

  private void setCap() {
    int prIndex = 0;
    int[] primes = {3, 11, 23, 47, 89, 97, 193, 389};
    while (data.length >= primes[prIndex]) {
      prIndex++;
    }
    capacity = primes[prIndex];
  }

  private void rehash(Entry<K,V>[] temp) {
    Entry<K,V>[] newHash = new Entry[capacity];
    Entry<K,V>[] pairs = new Entry[size];
    int pairIndex = 0;
    // get all entries from old hashmap
    for (Entry<K, V> kvEntry : temp) {
      Entry<K, V> curr = kvEntry;
      // go through bucket
      while (curr != null) {
        pairs[pairIndex++] = curr;
        curr = curr.next;
      }
    }
    // have filled key array
    data = newHash;
    pairIndex = 0;
    // rehash old hasmap keys into new hashmap since capacity changes
    for (int i = 0; i < size; i++) {
      insert(pairs[pairIndex].key,pairs[pairIndex].value);
      size--;
      pairIndex++;
    }
  }

  private void grow() {
    // temp to hold old hashmap
    Entry<K,V>[] temp = data;
    setCap();
    // create new hashmap with next largest prime # capacity
    rehash(temp);
  }

  @Override
  public void insert(K k, V v) throws IllegalArgumentException {
    if (k == null || has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    Entry<K,V> current = data[index];

    if (current == null) {
      data[index] = new Entry<>(k,v);
      size++;
      loadFactor = ((float) size) / capacity;
      if (loadFactor >= DEFAULT_LOAD_FACTOR) {
        grow();
      }
      return;
    }
    while (current.next != null) {
      current = current.next;
    }
    current.next = new Entry<>(k,v);
    size++;
  }

  @Override
  public V remove(K k) throws IllegalArgumentException {
    if (k == null || !has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    Entry<K,V> current = data[index];
    V temp = null;
    // if only node in the list
    if (current.next == null) {
      temp = current.value;
      data[index] = null;
      size--;
      return temp;
    }
    //if first node in the list
    if (current.key.equals(k)) {
      temp = current.value;
      data[index] = current.next;
      size--;
      return temp;
    }
    while (current.next.key != k) {
      current = current.next;
    }
    temp = current.next.value;
    current.next = current.next.next;
    size--;
    return temp;
  }

  @Override
  public void put(K k, V v) throws IllegalArgumentException {
    if (k == null || !has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    Entry<K,V> current = data[index];
    while (current != null) {
      if (current.key == k) {
        current.value = v;
        return;
      }
      current = current.next;
    }
  }

  @Override
  public V get(K k) throws IllegalArgumentException {
    if (k == null || !has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    Entry<K,V> current = data[index];
    while (current != null) {
      if (current.key == k) {
        return current.value;
      }
      current = current.next;
    }
    return null;
  }

  @Override
  public boolean has(K k) {
    if (k != null) {
      int index = k.hashCode() % capacity;
      Entry<K, V> current = data[index];

      // Traverse the linked list at the specified index
      while (current != null) {
        if (current.key.equals(k)) {
          return true; // Key found in the linked list
        }
        current = current.next;
      }

      // Key not found in the linked list
      return false;
    }
    return false;
  }

  @Override
  public int size() {
    return size;
  }

  @Override
  public Iterator<K> iterator() {
    return new HashIterator();
  }

  private class HashIterator implements Iterator<K> {

    private int currentIndex; // Index for array traversal
    private Entry<K,V> currentEntry; // Current entry in the linked list

    HashIterator() {
      currentIndex = 0;
      currentEntry = null;
      findNext(); // Move to the first valid entry
    }

    @Override
    public boolean hasNext() {
      return currentEntry != null;
    }

    @Override
    public K next() {
      if (!hasNext()) {
        throw new NoSuchElementException();
      }

      K key = currentEntry.key;
      currentEntry = currentEntry.next; // Move to the next entry in the linked list

      // If the current linked list is exhausted, find the next valid entry in the array
      if (currentEntry == null) {
        findNext();
      }

      return key;
    }

    // Helper method to find the next valid entry in the array
    private void findNext() {
      while (currentIndex < data.length && data[currentIndex] == null) {
        currentIndex++;
      }

      // If currentIndex is within bounds, update currentEntry
      if (currentIndex < data.length) {
        currentEntry = data[currentIndex];
        currentIndex++;
      } else {
        currentEntry = null; // Reached the end of the array
      }
    }
  }
}
