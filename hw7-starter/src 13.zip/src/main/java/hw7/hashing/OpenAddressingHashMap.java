package hw7.hashing;

import hw7.Map;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class OpenAddressingHashMap<K, V> implements Map<K, V> {
  private static final int[] PRIMES = {5, 11, 23, 47, 97, 197, 397, 797, 1597, 3203, 6421, 12853,
    25717, 51437,102877, 205759, 411527, 823117, 1646237,3292489, 6584983, 13169977};
  private static final int DEFAULT_CAPACITY = 5;
  private static final float DEFAULT_LOAD_FACTOR = 0.75f;

  private int capacity;
  private float loadFactor;
  private int size;
  private int tsSize;
  private int prIndex;
  private Entry<K, V>[] data;

  /**
   * Instantiate JdkHashMap.
   */
  public OpenAddressingHashMap() {
    capacity = DEFAULT_CAPACITY;
    loadFactor = DEFAULT_LOAD_FACTOR;
    data = new Entry[capacity];
    size = 0;
    tsSize = 0;
    prIndex = 1;
  }

  // Entry to store a key, and a value pair.
  private static class Entry<K,V> {
    K key;
    V value;

    Entry(K k, V v) {
      this.key = k;
      this.value = v;
    }
  }

  public int getCapacity() {
    return capacity;
  }

  private void setCap() {
    if (prIndex < PRIMES.length) {
      capacity = PRIMES[prIndex];
      prIndex++;
      return;
    }
    capacity = capacity * 2 + 1;
  }

  private void grow() {
    // temp to hold old hashmap
    Entry<K,V>[] temp = data;
    setCap();

    // create new hashmap with next largest prime # capacity
    Entry<K,V>[] newHash = new Entry[capacity];
    Entry<K,V>[] pairs = new Entry[size];
    int pairIndex = 0;
    // get all entries from old hashmap

    for (Entry<K, V> kvEntry : temp) {
      if (kvEntry != null && !kvEntry.key.equals("TS")) {
        pairs[pairIndex++] = kvEntry;
      }
    }
    // have filled entry array
    data = newHash;
    pairIndex = 0;
    // rehash old hashmap keys into new hashmap since capacity changes
    for (int i = 0; i < size; i++) {
      insert(pairs[pairIndex].key,pairs[pairIndex].value);
      size--;
      pairIndex++;
    }
    // rehashing removes tombstones
    tsSize = 0;
  }

  private void checkLoadFactor() {
    loadFactor = ((float) size + tsSize) / capacity;
    if (loadFactor >= DEFAULT_LOAD_FACTOR) {
      grow();
      loadFactor = ((float) size + tsSize) / capacity;
    }
  }

  @Override
  public void insert(K k, V v) throws IllegalArgumentException {
    if (k == null || has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    index = (index < 0) ? index + capacity : index;
    Entry<K,V> current = data[index];

    // element at index is empty or has TS
    if (current == null || current.key.equals("TS")) {
      data[index] = new Entry<>(k,v);
      size++;
      checkLoadFactor();
      return;
    }
    // move current 1 element forward
    index = ++index % capacity;
    current = data[index];

    // find next available spot
    int quadProbeCount = 1;
    while (current != null) {
      // check for TS
      if (current.key.equals("TS")) {
        tsSize--;
        size++;
        current.key = k;
        current.value = v;
        checkLoadFactor();
        return;
      }

      // move to the next entry (first 5 searches are quad, then linear)
      if (quadProbeCount > 5) {
        current = data[++index % capacity];
      } else {
        index = (index + quadProbeCount * quadProbeCount) % capacity;
        current = data[index];
        quadProbeCount++;
      }
    }

    // found empty entry
    data[index] = new Entry<>(k,v);
    size++;
    checkLoadFactor();
  }

  private V removeEdgeCases(int index,K k) {
    // key corresponds to k else shifted due to probing
    if (data[index].key.equals(k)) {
      V temp;
      temp = data[index].value;
      tsSize++;
      size--;
      data[index].key = (K)"TS";
      return temp;
    }
    // move to next entry
    index = ++index % capacity;
    // traverse hashmap to find entry (shifted due to probing)
    while (data[index] != null && !data[index].key.equals(k)) {
      index = ++index % capacity;
    }
    V temp;
    temp = data[index].value;
    tsSize++;
    size--;
    data[index].key = (K)"TS";
    return temp;
  }

  @Override
  public V remove(K k) throws IllegalArgumentException {
    if (k == null || !has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    index = (index < 0) ? index + capacity : index;
    return removeEdgeCases(index,k);
  }

  // TODO can put convert TS to an entry? if so that means tsSize must dec
  // TODO can we have null string values as the key?
  @Override
  public void put(K k, V v) throws IllegalArgumentException {
    if (k == null || !has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    index = (index < 0) ? index + capacity : index;
    // key corresponds to k else shifted due to probing
    if (data[index].key.equals(k)) {
      data[index].value = v;
      return;
    }
    // move to next entry
    index = ++index % capacity;
    // traverse hashmap to find entry (shifted due to probing)
    while (data[index] != null && !data[index].key.equals(k)) {
      index = ++index % capacity;
    }
    // found entry corresponding with key corresponding to k
    data[index].value = v;

  }

  @Override
  public V get(K k) throws IllegalArgumentException {
    if (k == null || !has(k)) {
      throw new IllegalArgumentException();
    }
    int index = k.hashCode() % capacity;
    index = (index < 0) ? index + capacity : index;
    // key corresponds to k else shifted due to probing
    if (data[index].key.equals(k)) {
      return data[index].value;
    }
    // move to next entry
    index = ++index % capacity;
    // traverse hashmap to find entry (shifted due to probing)
    while (data[index] != null && !data[index].key.equals(k)) {
      index = ++index % capacity;
    }
    return data[index].value;
  }

  @Override
  public boolean has(K k) {
    if (k != null) {
      int index = k.hashCode() % capacity;
      index = (index < 0) ? index + capacity : index;

      // Check if the entry at the computed index matches the key
      if (data[index] != null && data[index].key.equals(k)) {
        return true;
      }

      // Check for probing (linear probing in this case)
      // start at 1 since we already know curr element isnt a match
      for (int i = 1; i < capacity; i++) {
        int newIndex = (index + i) % capacity;

        // Check if the entry at the probed index matches the key
        if (data[newIndex] != null && data[newIndex].key.equals(k)) {
          return true;
        }
      }
    }
    // not in hashmap
    return false;
  }

  @Override
  public int size() {
    return size;
  }

  @Override
  public Iterator<K> iterator() {
    return new HashIterator();
  }

  private class HashIterator implements Iterator<K> {

    private int currentIndex; // Index for array traversal

    HashIterator() {
      currentIndex = 0;
      findNext(); // Move to the first valid entry
    }

    @Override
    public boolean hasNext() {
      return currentIndex < data.length;
    }

    @Override
    public K next() {
      if (!hasNext()) {
        throw new NoSuchElementException();
      }

      K key = data[currentIndex].key;
      currentIndex++;

      // If currentIndex is within bounds, find the next non-null entry
      findNext();

      return key;
    }

    // Helper method to find the next valid entry in the array
    private void findNext() {
      while (currentIndex < data.length && (data[currentIndex] == null || data[currentIndex].key.equals("TS"))) {
        currentIndex++;
      }
    }
  }

}
