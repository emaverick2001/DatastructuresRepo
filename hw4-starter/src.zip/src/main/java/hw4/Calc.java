package hw4;

import exceptions.EmptyException;
import java.util.Scanner;

/**
 * A program for an RPN calculator that uses a stack.
 */
public final class Calc {
  /**
   * The main function.
   *
   * @param args Not used.
   */
  public static void main(String[] args) {
    Scanner read = new Scanner(System.in);  // Create a Scanner object
    boolean shouldContinue = true;
    String userInput;
    LinkedStack<Integer> operationList = new LinkedStack<>();
    int operand;
    int operandOne = 0;
    int operandTwo = 0;

    //main program that uses a while loop
    while (shouldContinue) {
      userInput = read.next();
      //check user input for operators/integers
      // need to validate input for operators and integers

      switch (userInput) {
        case "!":
          shouldContinue = false;
          break;
        case ".":
          try {
            int frontValue = operationList.top();
            System.out.println(frontValue);
          } catch (EmptyException e) {
            System.out.println("ERROR: no values in stack");
          }
          break;
        case "?":
          System.out.println(operationList);
          break;
        case "+":
          try {
            operandTwo = operationList.top();
            operationList.pop();
            operandOne = operationList.top();
            operationList.pop();
            operandOne += operandTwo;
            operationList.push(operandOne);
          } catch (EmptyException e) {
            operationList.push(operandTwo);
            System.out.println("ERROR: not enough operands to perform calculation");
          }
          break;
        case "-":
          try {
            operandTwo = operationList.top();
            operationList.pop();
            operandOne = operationList.top();
            operationList.pop();
            operandOne -= operandTwo;
            operationList.push(operandOne);
          } catch (EmptyException e) {
            operationList.push(operandTwo);
            System.out.println("ERROR: not enough operands to perform calculation");
          }
          break;
        case "*":
          try {
            operandTwo = operationList.top();
            operationList.pop();
            operandOne = operationList.top();
            operationList.pop();
            operandOne *= operandTwo;
            operationList.push(operandOne);
          } catch (EmptyException e) {
            operationList.push(operandTwo);
            System.out.println("ERROR: not enough operands to perform calculation");
          }
          break;
        case "/":
          try {
            operandTwo = operationList.top();
            operationList.pop();
            operandOne = operationList.top();
            operationList.pop();
            operandOne /= operandTwo;
            operationList.push(operandOne);
          } catch (EmptyException e) {
            operationList.push(operandTwo);
            System.out.println("ERROR: not enough operands to perform calculation");
          } catch (ArithmeticException e) {
            operationList.push(operandOne);
            operationList.push(operandTwo);
            System.out.println("ERROR: division by 0");
          }
          break;
        case "%":
          try {
            operandTwo = operationList.top();
            operationList.pop();
            operandOne = operationList.top();
            operationList.pop();
            operandOne %= operandTwo;
            operationList.push(operandOne);
          } catch (EmptyException e) {
            operationList.push(operandTwo);
            System.out.println("ERROR: not enough operands to perform calculation");
          } catch (ArithmeticException e) {
            operationList.push(operandOne);
            operationList.push(operandTwo);
            System.out.println("ERROR: modulo by 0");
          }
          break;
        default:
          try {
            operand = Integer.parseInt(userInput);
            operationList.push(operand);
          } catch (NumberFormatException e) {
            System.out.println("ERROR: bad token");
          }
          break;
      }

    }

  }
}
