package hw3;

import hw3.list.MeasuredIndexedList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class MeasuredIndexedListTest {

  private static final int LENGTH = 15;
  private static final int DEFAULT_VALUE = 3;

  private MeasuredIndexedList<Integer> measuredIndexedList;

  @BeforeEach
  void setup() {
    measuredIndexedList = new MeasuredIndexedList<>(LENGTH, DEFAULT_VALUE);
  }

  @Test
  @DisplayName("MeasuredIndexedList starts with zero reads")
  void zeroReadsStart() {
    assertEquals(0, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("MeasuredIndexedList starts with zero writes")
  void zeroWritesStart() {
    assertEquals(0, measuredIndexedList.mutations());
  }

  // GET

  @Test
  @DisplayName("get increases accessCount")
  void getIncAccessCount() {
    measuredIndexedList.get(0);
    assertEquals(1, measuredIndexedList.accesses());
  }

  //PUT

  @Test
  @DisplayName("put increases mutateCount and accessCount")
  void putIncMutateCount() {
    measuredIndexedList.put(0,5);
    assertEquals(1, measuredIndexedList.mutations());
  }

  // COUNT

  @Test
  @DisplayName("count increases accessCount")
  void countIncAccessCount() {
    measuredIndexedList.count(3);
    assertEquals(15, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("count returns correct countValue for default value")
  void countGivesValidCountForDefaultValue() {
    assertEquals(15, measuredIndexedList.count(3));
  }

  @Test
  @DisplayName("count returns correct countValue for nonexistent value")
  void countGivesValidCountForNonexistentValue() {
    assertEquals(0, measuredIndexedList.count(5));
  }

  @Test
  @DisplayName("count returns correct countValue for specific value beginning of list")
  void countGivesValidCountForSpecificValueBeginningList() {
    measuredIndexedList.put(0,1);
    assertEquals(1, measuredIndexedList.count(1));
  }

  @Test
  @DisplayName("count returns correct countValue for specific value end of list")
  void countGivesValidCountForSpecificValueEndList() {
    measuredIndexedList.put(14,1);
    assertEquals(1, measuredIndexedList.count(1));
  }

  @Test
  @DisplayName("count returns correct countValue for specific value with multiple in list")
  void countGivesValidCountForMultipleInList() {
    measuredIndexedList.put(14,1);
    measuredIndexedList.put(0,1);
    measuredIndexedList.put(6,1);
    assertEquals(3, measuredIndexedList.count(1));
  }

  @Test
  @DisplayName("count returns correct accessValue for specific value with multiple in list")
  void countGivesValidAccessCountForMultipleInList() {
    measuredIndexedList.put(14,1);
    measuredIndexedList.put(0,1);
    measuredIndexedList.put(6,1);
    measuredIndexedList.count(1);
    assertEquals(15, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("count updates correct accessCount for specific value of list")
  void countGivesValidAccessCountForSpecificValue() {
    measuredIndexedList.put(0,1);
    measuredIndexedList.count(1);
    assertEquals(15, measuredIndexedList.accesses());
  }

}
