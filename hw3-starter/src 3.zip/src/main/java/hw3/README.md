# Discussion

## PART I: MEASURED IndexedList

**Discuss from a design perspective whether iterating over a `MeasuredIndexedList`should 
affect the accesses and mutation counts. Note that for the purposes of this assignment we are NOT 
asking you to rewrite the `ArrayIndexedListIterator` to do so. However, if you wanted to include 
the `next()` and/or `hasNext()` methods in the statistics measured, can you inherit 
`ArrayIndexedListIterator` from `ArrayIndexedList` and override the relevant methods, or not? 
Explain.**
Iterating over MeasuredIndexedList (assuming its using an iterator)should affect the accesses but not the mutation counts since elements are only being accessed and not manipulated in the process of iterating over the list. The next()
function needs to use the get() method to access the element in the list, and doing so accesses the list. Also,
the iterator uses its own hasNext() method as a condition to check if there are available indexes to iterate through. 


You cant inherit the ArrayIndexedListIterator from ArrayIdexedListIterator since the iterator is private and special to the class its in even though MeasuredIndexedList extends ArrayIndexedList. Also doing so won't be useful since MeasuredIndexedList doesn't implement Iterable and thus 
also Iterator and if it were to implement its own iterator it would need to create its own iterator with its hasnext and next methods. 



## PART II: EXPERIMENTS

**Explain the mistake in the setup/implementation of the experiment which resulted in a discrepancy 
between the results and what is expected from each sorting algorithm.**
I noticed in the descending.data file, every 11th data point is missing a 4th digit causing the data not be fully a descending data set. If we used the insertion sort function for example, it would make more swaps since it would now have to order values with different thousands/ hundreds places and thus call the mutations and accessors functions more often.
Another error is in





## PART III: ANALYSIS OF SELECTION SORT

**Determine exactly how many comparisons C(n) and assignments A(n) are performed by this 
implementation of selection sort in the worst case. Both of those should be polynomials of degree 2 
since you know that the asymptotic complexity of selection sort is O(n^2).**
The minimum selection sort implementation has 
