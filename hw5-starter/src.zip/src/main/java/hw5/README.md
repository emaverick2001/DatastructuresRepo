# Discussion

## Flawed Deque
1. doesnt throw empty exception when removeBack or removeFront is called on empty deque
2. doesnt throw empty exception when back is called on an empty deque
3. InsertBack adds everyother call. For instance on the first call, it adds a node. On the second call it skips adding the node. On the Third it adds a node and follows adding every other node (evey odd call it will add a node)

## Hacking Linear Search
 In the MoveToFrontLinkedSet, remove and prepend within the find function allows for a quicker way to find already searched elements in the future by adding them to the front of the list. 
 In the TransposeArraySet, swaps gradually move recently searched elements to the front of the set each time the element is searched for. 


## Profiling

