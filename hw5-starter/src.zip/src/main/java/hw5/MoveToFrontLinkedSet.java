package hw5;


/**
 * Set implemented using a doubly linked list and move-to-front heuristic.
 *
 * @param <T> Element type.
 */
public class MoveToFrontLinkedSet<T> extends LinkedSet<T> {

  MoveToFrontLinkedSet() {
    head = null;
    tail = null;
    numElements = 0;
  }

  // Adds to the front of this linked-list in O(1)
  // Pre: t != null && has(t) == false
  // Post: has(t) == true && tail.data == t
  protected void prepend(T t) {
    if (head == null) {
      head = new Node<>(t);
      tail = head;
    } else {
      Node<T> node = new Node<>(t);
      node.next = head;
      head.prev = node;
      head = node;
    }
    numElements++;
  }

  // Performs linear search.
  // Returns the target node containing t or null if t was not found.
  // Pre: t != null

  protected Node<T> findMoveToFrontHeuristic(T t) {
    for (Node<T> n = head; n != null; n = n.next) {
      if (n.data.equals(t)) {
        // remove target element
        remove(t);
        // add to front of list to make element easier to find
        prepend(t);
        return n;
      }
    }
    return null;
  }

  @Override
  public boolean has(T t) {
    return findMoveToFrontHeuristic(t) != null;
  }

  // TODO: incorporate move-to-front heuristic each time a value is accessed.
  //  Override the relevant method(s) from LinkedSet.

  /**
   * Driver program to visualize/test this implementation.
   *
   * @param args command-line arguments.
   */
  public static void main(String[] args) {
    MoveToFrontLinkedSet<Integer> test = new MoveToFrontLinkedSet<>();
    test.insert(5);
    test.insert(6);
    test.insert(10);
    test.insert(10);


  }
}


