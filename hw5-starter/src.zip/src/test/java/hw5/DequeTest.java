package hw5;

import exceptions.EmptyException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public abstract class DequeTest {

  private Deque<String> deque;

  @BeforeEach
  public void setUp() {
    this.deque = createDeque();
  }

  protected abstract Deque<String> createDeque();

  @Test
  @DisplayName("Deque is empty after construction.")
  public void testConstructor() {
    assertTrue(deque.empty());
    assertEquals(0, deque.length());
  }

  // TODO Add more tests
  @Test
  @DisplayName("Deque throws empty exception when front is called")
  public void testFrontEmpty() {
    try {
      deque.front();
      fail("deque doesnt throw empty exception");
    } catch (EmptyException e){
      return;
    }
  }

  @Test
  @DisplayName("Deque throws empty exception when back is called")
  public void testBackEmpty() {
    try {
      deque.back();
      fail("deque doesnt throw empty exception");
    } catch (EmptyException e){
      return;
    }
  }


  @Test
  @DisplayName("Deque throws empty exception when removeBack is called")
  public void testRemoveBackEmpty() {
    try {
      deque.removeBack();
      fail("deque doesnt throw empty exception");
    } catch (EmptyException e){
      return;
    }
  }

  @Test
  @DisplayName("Deque throws empty exception when removeFront is called")
  public void testRemoveFrontEmpty() {
    try {
      deque.removeFront();
      fail("deque doesnt throw empty exception");
    } catch (EmptyException e){
      return;
    }
  }

  @Test
  @DisplayName("Deque length 1 when insertFront called.")
  public void testInsertFront() {
    deque.insertFront("1");
    assertFalse(deque.empty());
    assertEquals(1,deque.length());
  }

  @Test
  @DisplayName("Deque prints correct value when front called")
  public void testFrontOneNode() {
    deque.insertFront("1");
    assertFalse(deque.empty());
    assertEquals("1",deque.front());
  }

  @Test
  @DisplayName("Deque prints correct value when front called")
  public void testFrontMultipleNodes() {
    deque.insertFront("1");
    deque.insertFront("2");
    deque.insertFront("3");
    assertFalse(deque.empty());
    assertEquals("3",deque.front());
  }

  @Test
  @DisplayName("Deque prints list correctly")
  public void testInsertFrontMultipleNodes() {
    deque.insertFront("1");
    deque.insertFront("2");
    deque.insertFront("3");
    assertFalse(deque.empty());
    for (int i = 3; i > 0; i--){
      assertEquals(i + "" ,deque.front());
      deque.removeFront();
    }
    assertEquals(0,deque.length());
    assertTrue(deque.empty());

  }

  @Test
  @DisplayName("Deque length 1 when insertBack called.")
  public void testInsertBack() {
    deque.insertBack("1");
    assertFalse(deque.empty());
    assertEquals(1,deque.length());
  }

  @Test
  @DisplayName("Deque prints correct value when front called")
  public void testBackOneNode() {
    deque.insertBack("1");
    assertFalse(deque.empty());
    assertEquals("1",deque.back());
  }

  @Test
  @DisplayName("Deque prints correct value when front called")
  public void testBackMultipleNodes() {
    deque.insertBack("1");
    deque.insertBack("2");
    deque.insertBack("3");
    assertFalse(deque.empty());
    assertEquals("3",deque.back());
  }

//  @Test
//  @DisplayName("Deque prints list correctly")
//  public void testInsertBackMultipleNodes() {
//    deque.insertBack("1");
//    deque.insertBack("2");
//    deque.insertBack("3");
//    assertFalse(deque.empty());
//
//    for (int i = 1; i <= 3; i++){
//      assertEquals(i + "" ,deque.front());
//      deque.removeFront();
//    }
//    assertEquals(0,deque.length());
//    assertTrue(deque.empty());
//
//  }

  @Test
  @DisplayName("Deque insertBack skips every other call")
  public void testInsertBackManyNodes() {
    deque.insertBack("1");
    assertEquals(1,deque.length());
    assertEquals("1",deque.back());
    deque.insertBack("2");
    assertEquals(1,deque.length());
    assertEquals("1",deque.back());
    deque.insertBack("2");
    assertEquals(2,deque.length());
    assertEquals("2",deque.back());
    deque.insertBack("3");
    assertEquals(2,deque.length());
    assertEquals("2",deque.back());
    deque.insertBack("3");
    assertEquals(3,deque.length());
    assertEquals("3",deque.back());
  }
  @Test
  @DisplayName("Deque insertFront adds node each call")
  public void testInsertFrontManyNodes() {
    deque.insertFront("1");
    assertEquals(1,deque.length());
    assertEquals("1",deque.front());
    deque.insertFront("2");
    assertEquals(2,deque.length());
    assertEquals("2",deque.front());
    deque.insertFront("3");
    assertEquals(3,deque.length());
    assertEquals("3",deque.front());
    deque.insertFront("4");
    assertEquals(4,deque.length());
    assertEquals("4",deque.front());
  }

  @Test
  @DisplayName("Deque removes entire list")
  public void testRemoveBackMultipleNodes() {
    deque.insertBack("1");
    deque.insertBack("2");
    deque.insertBack("3");
    assertFalse(deque.empty());
    for (int i = 3; i > 0; i--){
      assertEquals(i,deque.length());
      deque.removeBack();
    }
    assertEquals(0,deque.length());
    assertTrue(deque.empty());

  }

  @Test
  @DisplayName("Deque removes entire list")
  public void testRemoveFrontMultipleNodes() {
    deque.insertBack("1");
    deque.insertBack("2");
    deque.insertBack("3");
    assertFalse(deque.empty());
    for (int i = 3; i > 0; i--){
      assertEquals(i,deque.length());
      deque.removeFront();
    }
    assertEquals(0,deque.length());
    assertTrue(deque.empty());

  }

}
