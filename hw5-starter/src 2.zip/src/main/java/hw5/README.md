# Discussion

## Flawed Deque
1. doesn't throw empty exception when removeBack is called on empty deque
   Unit test: testRemoveBackEmpty()
   Guess: There is no check for when the deque is empty thus no implementation for throwing Empty exception error when removing back

2. doesn't throw empty exception when removeFront is called on empty deque
   Unit test: testRemoveFrontEmpty()
   Guess: There is no check for when the deque is empty thus no implementation for throwing Empty exception error when removing front

3. doesn't throw empty exception when back is called on an empty deque
   Unit test: testBackEmpty()
   Guess: The exception thrown is LengthException instead of Empty exception

4. InsertBack adds every other call. For instance on the first call, it adds a node. On the second call it skips adding the node. On the Third it adds a node and follows adding every other node (evey odd call it will add a node)
   Unit test: testInsertBackAndRemoveFrontMultipleNodes(), testInsertBackAndRemoveBackMultipleNodes(), testInsertBackManyNodes()
   Guess: Every odd call to insert back adds a node, every even call is skipped


## Hacking Linear Search
 In the MoveToFrontLinkedSet, remove and prepend within the find function allows for a quicker way to find already searched elements in the future by adding them to the front of the list.
   This makes it so that when searching for the element it, find doesn't have to traverse the whole list and only just the first element
 In the TransposeArraySet, swaps gradually move recently searched elements to the front of the set each time the element is searched for. 
   This makes it so that with each access of a specific element, its location in the array moves closer to the front (the searched element is removed and replaced by the element before it).


## Profiling

